import * as data from "../helpers/default_data.json"
import * as pokemonbattle from "../locators/pokemonbattle_page.json"

describe('Проверка покупки аватара', function () {

   it('Покупка автара от входа до выхода из аккаунта', function () {
        cy.visit('/');
        cy.wait(1000);
        cy.get(pokemonbattle.email).type(data.login);
        cy.get(pokemonbattle.password).type(data.password);
        cy.get(pokemonbattle.login_button).should('be.visible');
        cy.get(pokemonbattle.login_button).click()
        cy.wait(2000);
        cy.get('.header__container > .header__id').click();
        cy.wait(1000);
        cy.get('[href="/shop"]').click();
        cy.get(pokemonbattle.skin_number).should('have.class', 'shop__item available');
        cy.get(pokemonbattle.buy_skin_button).click()
        cy.wait(1000);
        cy.get('.pay__payform-v2 > :nth-child(2) > .pay_base-input-v2').type(data.card_number);
        cy.get(':nth-child(1) > .pay_base-input-v2').type(data.card_expire_date);
        cy.get('.pay-inputs-box > :nth-child(2) > .pay_base-input-v2').type(data.card_cvv);
        cy.get('.pay__input-box-last-of > .pay_base-input-v2').type(data.card_holder);
        cy.get('.pay-btn').should('have.class', 'pay-btn pay-btn_all pay-btn_desk');
        cy.get('.pay-btn').click();
        cy.wait(1000);
        cy.get('#cardnumber').type('56456');
        cy.get('.payment__submit-button').should('have.class', 'payment__submit-button payment__active');
        cy.get('.payment__submit-button').click();
        cy.get('.payment__adv').contains('Вернуться в магазин');
        cy.get('.payment__adv').should('have.css', 'color', 'rgb(85, 137, 241)')
        cy.get('.payment__adv').click();
        cy.get(pokemonbattle.login_exit).should('be.visible');
        cy.get(pokemonbattle.login_exit).click()
    })

    
})
